package com.example.listamultimedia;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity implements ListaFragment.OnNavegacionListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Activamos EdgeToEdge para aprovechar la pantalla completa
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Aseguramos que los Insets sean aplicados correctamente para una experiencia EdgeToEdge
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            // Establecemos el padding para ajustar los márgenes de la barra de estado y barra de navegación
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Añadir el fragmento de lista si es la primera vez que se lanza la actividad
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.contenedor_fragmentos, new ListaFragment())
                    .commit();
        }
    }


    @Override
    public void mostrarDetalle() {
        // Usamos commit para realizar la transacción
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.contenedor_fragmentos, new DetalleFragment())
                .addToBackStack(null)
                .commit();
    }


    @Override
    public void mostrarLista() {
        // Vuelve al fragmento anterior (de lista)
        getSupportFragmentManager().popBackStack();
    }
}