package com.example.listamultimedia;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;


/*
 * fragmento de una aplicación Android que se encarga de gestionar la visualización de un recurso multimedia (ya sea video, audio o contenido web) y los controles asociados a este. En concreto, la clase está diseñada para ser parte de una interfaz de usuario donde se muestra un detalle de un recurso seleccionado en otra parte de la aplicación, probablemente en una lista de recursos multimedia.
 */
public class DetalleFragment extends Fragment {

    private ViewModelRecursos viewModelRecursos;
    private VideoView videoVista;
    private MediaController controladorMedia;
    private LinearLayout layoutAudio;
    private Button botonReproducirAudio;
    private Button botonPausarAudio;
    private WebView vistaWeb;
    private Button botonVolver;
    private MediaPlayer reproductorAudio;

    public DetalleFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View vista = inflater.inflate(R.layout.fragment_detalle, container, false);
        videoVista = vista.findViewById(R.id.video_vista);
        layoutAudio = vista.findViewById(R.id.layout_audio);
        botonReproducirAudio = vista.findViewById(R.id.boton_reproducir_audio);
        botonPausarAudio = vista.findViewById(R.id.boton_pausar_audio);
        vistaWeb = vista.findViewById(R.id.vista_web);
        botonVolver = vista.findViewById(R.id.boton_volver);

        // Inicializamos el ViewModel
        viewModelRecursos = new ViewModelProvider(requireActivity()).get(ViewModelRecursos.class);

        // Observar cambios en el recurso seleccionado
        viewModelRecursos.getRecursoSeleccionado().observe(getViewLifecycleOwner(), new Observer<Recurso>() {
            @Override
            public void onChanged(Recurso elemento) {
                if (elemento != null) {
                    mostrarDetalle(elemento); // Muestra el detalle del recurso seleccionado
                }
            }
        });

        botonVolver.setOnClickListener(v -> {
            if(getActivity() instanceof ListaFragment.OnNavegacionListener) {
                ((ListaFragment.OnNavegacionListener)getActivity()).mostrarLista();
            }
        });

        return vista;
    }

    private void mostrarDetalle(Recurso elemento) {
        // Ocultar vistas antes de mostrar la correcta
        videoVista.setVisibility(View.GONE);
        layoutAudio.setVisibility(View.GONE);
        vistaWeb.setVisibility(View.GONE);

        // Mostrar el recurso correspondiente
        switch (elemento.getTipo()) {
            case VIDEO:
                mostrarVideo(elemento);
                break;
            case AUDIO:
                mostrarAudio(elemento);
                break;
            case WEB:
                mostrarWeb(elemento);
                break;
        }
    }

    private void mostrarVideo(Recurso elemento) {
        videoVista.setVisibility(View.VISIBLE);
        Uri uriVideo = Uri.parse("android.resource://" + requireContext().getPackageName() + "/" + elemento.getIdRecurso());
        videoVista.setVideoURI(uriVideo);

        MediaController controladorMedia = new MediaController(requireContext());
        videoVista.setMediaController(controladorMedia);
        controladorMedia.setAnchorView(videoVista);

        videoVista.setOnPreparedListener(mp -> {
            int posicion = viewModelRecursos.getPosicionVideo().getValue() != null ?
                    viewModelRecursos.getPosicionVideo().getValue() : 0;
            boolean reproduciendo = viewModelRecursos.isVideoReproduciendo().getValue() != null ?
                    viewModelRecursos.isVideoReproduciendo().getValue() : false;

            videoVista.seekTo(posicion);
            if (reproduciendo) {
                videoVista.start();
            }
        });

        // Iniciar reproducción si es necesario (por si onPrepared no se dispara)
        if (viewModelRecursos.isVideoReproduciendo().getValue() != null &&
                viewModelRecursos.isVideoReproduciendo().getValue()) {
            videoVista.start();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (videoVista != null) {
            // Guardamos la posición y el estado de la reproducción
            viewModelRecursos.setPosicionVideo(videoVista.getCurrentPosition());
            viewModelRecursos.setVideoReproduciendo(videoVista.isPlaying());
        }
        if (reproductorAudio != null) {
            // Guardamos la posición y el estado de la reproducción del audio
            viewModelRecursos.setPosicionAudio(reproductorAudio.getCurrentPosition());
            viewModelRecursos.setAudioReproduciendo(reproductorAudio.isPlaying());
        }
    }

    private void mostrarAudio(Recurso elemento) {
        layoutAudio.setVisibility(View.VISIBLE);
        if (reproductorAudio != null) {
            reproductorAudio.release();
        }
        reproductorAudio = MediaPlayer.create(getContext(), elemento.getIdRecurso());

        // Restaurar estado del audio
        Integer posicionAudio = viewModelRecursos.getPosicionAudio().getValue();
        if (posicionAudio != null && posicionAudio > 0) {
            reproductorAudio.seekTo(posicionAudio);
        }

        // Verificar si el audio estaba reproduciéndose
        Boolean isAudioReproduciendo = viewModelRecursos.isAudioReproduciendo().getValue();
        if (isAudioReproduciendo != null && isAudioReproduciendo) {
            reproductorAudio.start();
        }

        botonReproducirAudio.setOnClickListener(v -> {
            reproductorAudio.start();
            viewModelRecursos.setAudioReproduciendo(true);
        });

        botonPausarAudio.setOnClickListener(v -> {
            if (reproductorAudio.isPlaying()) {
                reproductorAudio.pause();
                viewModelRecursos.setAudioReproduciendo(false);
            }
        });
    }

    private void mostrarWeb(Recurso elemento) {
        vistaWeb.setVisibility(View.VISIBLE);
        WebSettings configuracionWeb = vistaWeb.getSettings();
        configuracionWeb.setJavaScriptEnabled(true);
        configuracionWeb.setDomStorageEnabled(true); // Necesario para algunas páginas

        // Añadir WebViewClient para manejar la carga
        vistaWeb.setWebViewClient(new WebViewClient () {
            @Override
            public void onPageFinished(WebView view, String url) {
                Log.d("DetalleFragment", "Página cargada: " + url);
            }
        });

        // Cargar URL
        try {
            vistaWeb.loadUrl(elemento.getUrlWeb());
        } catch (Exception e) {
            Log.e("DetalleFragment", "Error cargando URL: " + e.getMessage());
            Toast.makeText(getContext(), "Error al cargar la página", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (reproductorAudio != null) {
            if (reproductorAudio.isPlaying()) {
                reproductorAudio.stop();
            }
            reproductorAudio.release();
            reproductorAudio = null;
        }
        if (videoVista != null) {
            videoVista.stopPlayback(); // Detenemos la reproducción del VideoView
        }
    }

}