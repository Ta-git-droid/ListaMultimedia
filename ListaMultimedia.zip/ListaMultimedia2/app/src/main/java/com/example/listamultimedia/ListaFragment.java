package com.example.listamultimedia;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


public class ListaFragment extends Fragment implements AdaptadorMultimedia.OnElementoSeleccionadoListener {

    private RecyclerView recyclerView;
    private AdaptadorMultimedia adaptador;
    private List<Recurso> listaElementos;
    private ViewModelRecursos viewModelRecursos;

    public ListaFragment() {
        // Constructor vacío
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflamos el layout del fragmento
        View vista = inflater.inflate(R.layout.fragment_lista, container, false);

        // Configuración del RecyclerView
        recyclerView = vista.findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Inicialización del ViewModel
        viewModelRecursos = new ViewModelProvider(requireActivity()).get(ViewModelRecursos.class);

        // Inicialización de la lista de elementos con los recursos multimedia (audio, video, web)
        listaElementos = new ArrayList<>();

        // Añadimos los recursos multimedia
        cargarRecursos();

        // Configuramos el adaptador con la lista de elementos y el listener
        adaptador = new AdaptadorMultimedia(listaElementos, this);
        recyclerView.setAdapter(adaptador);

        // Se loggea la cantidad de elementos añadidos
        Log.d("ListaFragment", "Elementos en la lista: " + listaElementos.size());

        return vista;
    }

    private void cargarRecursos() {
        // Añadimos los recursos manualmente
        listaElementos.add(new Recurso("Nubes", "Movimiento de las nubes en un día de cielo azul", R.raw.nubes, Recurso.TipoRecurso.VIDEO, R.drawable.video));
        listaElementos.add(new Recurso("Girasoles", "Campo de girasoles en un atardecer de verano", R.raw.girasoles, Recurso.TipoRecurso.VIDEO, R.drawable.video));
        listaElementos.add(new Recurso("Piano", "Pequeña pieza tocada en piano", R.raw.piano, Recurso.TipoRecurso.AUDIO, R.drawable.audio));
        listaElementos.add(new Recurso("Pista de audio", "Pequeña pieza para desconectar", R.raw.pista1, Recurso.TipoRecurso.AUDIO, R.drawable.audio));
        listaElementos.add(new Recurso("Android", "El apasionante mundo de Android", "https://developer.android.com/?hl=es-419", Recurso.TipoRecurso.WEB, R.drawable.web));
        listaElementos.add(new Recurso("Arduino", "Aprende arduino", "https://www.arduino.cc/", Recurso.TipoRecurso.WEB, R.drawable.web));
    }

    @Override
    public void onElementoSeleccionado(Recurso recurso) {
        // Pasamos el recurso seleccionado al ViewModel
        viewModelRecursos.setRecursoSeleccionado(recurso);

        // Llamamos al método para mostrar el detalle
        if (getActivity() instanceof OnNavegacionListener) {
            ((OnNavegacionListener) getActivity()).mostrarDetalle();  // Aquí se llama el método
        }
    }


    // Interfaz para la navegación entre fragmentos
    public interface OnNavegacionListener {
        void mostrarDetalle();  // Método para mostrar el detalle
        void mostrarLista();    // Método para mostrar la lista
    }

}