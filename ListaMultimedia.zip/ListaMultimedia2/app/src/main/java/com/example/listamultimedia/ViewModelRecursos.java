package com.example.listamultimedia;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

/**
 * ViewModel para gestionar los recursos multimedia en la aplicación
 * Mantiene el estado del recurso seleccionado y las posiciones de reproducción de video, audio y contenido web
 */
public class ViewModelRecursos extends ViewModel {

    // Objeto SavedStateHandle para guardar el estado de los datos entre cambios de configuración
    private final SavedStateHandle savedState;

    // LiveData para el recurso seleccionado
    private final MutableLiveData<Recurso> recursoSeleccionado = new MutableLiveData<>();

    // LiveData para las posiciones de video y audio
    private final MutableLiveData<Integer> posicionVideo = new MutableLiveData<>(0);
    private final MutableLiveData<Integer> posicionAudio = new MutableLiveData<>(0);

    // LiveData para saber si los recursos están reproduciéndose
    private final MutableLiveData<Boolean> videoReproduciendo = new MutableLiveData<>(false);
    private final MutableLiveData<Boolean> audioReproduciendo = new MutableLiveData<>(false);

    // LiveData para la URL de la web y su visibilidad
    private final MutableLiveData<String> urlWeb = new MutableLiveData<>();
    private final MutableLiveData<Boolean> webVisible = new MutableLiveData<>(false);

    /**
     * Constructor del ViewModel que recibe un SavedStateHandle
     * @param savedState Estado guardado para mantener los datos tras cambios de configuración
     */
    public ViewModelRecursos(SavedStateHandle savedState) {
        this.savedState = savedState;
        Log.d("ViewModelRecursos", "ViewModel creado con SavedStateHandle");

        // Restaura el estado guardado en SavedStateHandle si existe
        if (savedState.contains("recurso_seleccionado")) {
            recursoSeleccionado.setValue(savedState.get("recurso_seleccionado"));
        }
        if (savedState.contains("posicion_video")) {
            posicionVideo.setValue(savedState.get("posicion_video"));
        }
        if (savedState.contains("posicion_audio")) {
            posicionAudio.setValue(savedState.get("posicion_audio"));
        }
        if (savedState.contains("video_reproduciendo")) {
            videoReproduciendo.setValue(savedState.get("video_reproduciendo"));
        }
        if (savedState.contains("audio_reproduciendo")) {
            audioReproduciendo.setValue(savedState.get("audio_reproduciendo"));
        }
        if (savedState.contains("url_web")) {
            urlWeb.setValue(savedState.get("url_web"));
        }
        if (savedState.contains("web_visible")) {
            webVisible.setValue(savedState.get("web_visible"));
        }
    }

    /**
     * Obtiene el recurso actualmente seleccionado
     * @return LiveData con el recurso seleccionado
     */
    public LiveData<Recurso> getRecursoSeleccionado() {
        Log.d("ViewModelRecursos", "Obteniendo recurso seleccionado");
        return recursoSeleccionado;
    }

    /**
     * Establece el recurso seleccionado
     * @param recurso El recurso a seleccionar
     */
    public void setRecursoSeleccionado(Recurso recurso) {
        Log.d("ViewModelRecursos", "Estableciendo recurso seleccionado: " + recurso.getTitulo());
        recursoSeleccionado.setValue(recurso);
        savedState.set("recurso_seleccionado", recurso); // Guardar el estado
    }

    /**
     * Obtiene la posición actual de reproducción del video
     * @return La posición en milisegundos
     */
    public LiveData<Integer> getPosicionVideo() {
        return posicionVideo;
    }

    /**
     * Establece la posición actual del video en la reproducción
     * @param posicion La nueva posición en milisegundos
     */
    public void setPosicionVideo(int posicion) {
        Log.d("ViewModelRecursos", "Estableciendo posición del video a: " + posicion + "ms.");
        posicionVideo.setValue(posicion);
        savedState.set("posicion_video", posicion); // Guardar el estado
    }

    /**
     * Obtiene la posición actual de reproducción del audio
     * @return La posición en milisegundos
     */
    public LiveData<Integer> getPosicionAudio() {
        return posicionAudio;
    }

    /**
     * Establece la posición actual del audio en la reproducción
     * @param posicion La nueva posición en milisegundos
     */
    public void setPosicionAudio(int posicion) {
        Log.d("ViewModelRecursos", "Estableciendo posición del audio a: " + posicion + "ms.");
        posicionAudio.setValue(posicion);
        savedState.set("posicion_audio", posicion); // Guardar el estado
    }

    /**
     * Obtiene el estado de reproducción del video
     * @return true si el video está reproduciendo, false si está pausado
     */
    public LiveData<Boolean> isVideoReproduciendo() {
        return videoReproduciendo;
    }

    /**
     * Establece el estado de reproducción del video
     * @param reproduciendo true si el video está en reproducción, false si está pausado
     */
    public void setVideoReproduciendo(boolean reproduciendo) {
        Log.d("ViewModelRecursos", "Estado de reproducción del video cambiado a: " + (reproduciendo ? "Reproduciendo" : "Pausado"));
        videoReproduciendo.setValue(reproduciendo);
        savedState.set("video_reproduciendo", reproduciendo); // Guardar el estado
    }

    /**
     * Obtiene el estado de reproducción del audio
     * @return true si el audio está reproduciendo, false si está pausado
     */
    public LiveData<Boolean> isAudioReproduciendo() {
        return audioReproduciendo;
    }

    /**
     * Establece el estado de reproducción del audio
     * @param reproduciendo true si el audio está en reproducción, false si está pausado
     */
    public void setAudioReproduciendo(boolean reproduciendo) {
        audioReproduciendo.setValue(reproduciendo);
        savedState.set("audio_reproduciendo", reproduciendo); // Guardar el estado
    }

    /**
     * Obtiene la URL de la web
     * @return La URL de la web
     */
    public LiveData<String> getUrlWeb() {
        return urlWeb;
    }

    /**
     * Establece la URL de la web
     * @param url La URL a establecer
     */
    public void setUrlWeb(String url) {
        Log.d("ViewModelRecursos", "Estableciendo URL web: " + url);
        urlWeb.setValue(url);
        savedState.set("url_web", url); // Guardar el estado
    }

    /**
     * Obtiene la visibilidad de la web
     * @return true si la web es visible, false si no
     */
    public LiveData<Boolean> isWebVisible() {
        return webVisible;
    }

    /**
     * Establece la visibilidad de la web
     * @param visible true si la web debe ser visible, false si no
     */
    public void setWebVisible(boolean visible) {
        Log.d("ViewModelRecursos", "Estableciendo visibilidad de la web a: " + (visible ? "Visible" : "Invisible"));
        webVisible.setValue(visible);
        savedState.set("web_visible", visible); // Guardar el estado
    }
}