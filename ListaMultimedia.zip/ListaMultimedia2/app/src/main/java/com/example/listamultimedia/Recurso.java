package com.example.listamultimedia;

import android.os.Parcel;
import android.os.Parcelable;


/*
 * Esta clase representa un recurso multimedia que puede ser de tipo vídeo, audio o un enlace web.
 * La clase implementa Parcelable
 * Permite serializar y deserializar objetos Recurso de manera eficiente, facilitando su transferencia entre actividades o fragmentos en Android.
 */

public class Recurso implements Parcelable {

    // Atributos de un recurso
    private String titulo;       // Título del recurso
    private String descripcion;  // Descripción del recurso
    private int idRecurso;       // Identificador del recurso en res/raw (para vídeos y audios)
    private String urlWeb;       // URL para recursos web
    private TipoRecurso tipo;    // Tipo de recurso (VIDEO, AUDIO, WEB)
    private boolean expandido;   // Indica si los detalles han sido desplegados o no
    private int idIcono;         // Identificador del icono representativo del recurso


    /**
     * Enumeración que define los tipos de recursos disponibles: VIDEO, AUDIO y WEB
     */
    public enum TipoRecurso {
        VIDEO,
        AUDIO,
        WEB
    }


    /**
     * Constructor para crear un recurso local (vídeo o audio)
     */
    private void inicializar(String titulo, String descripcion, TipoRecurso tipo, int idIcono) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.tipo = tipo;
        this.expandido = false;
        this.idIcono = idIcono;
    }

    public Recurso(String titulo, String descripcion, int idRecurso, TipoRecurso tipo, int idIcono) {
        inicializar(titulo, descripcion, tipo, idIcono);
        this.idRecurso = idRecurso;
    }

    public Recurso(String titulo, String descripcion, String urlWeb, TipoRecurso tipo, int idIcono) {
        inicializar(titulo, descripcion, tipo, idIcono);
        this.urlWeb = urlWeb;
    }



    // Métodos Getter y Setter

    // Devuelve el título del recurso
    public String getTitulo() {
        return titulo;
    }

    // Devuelve la descripción del recurso
    public String getDescripcion() {
        return descripcion;
    }

    // Devuelve el identificador del recurso en res/raw
    public int getIdRecurso() {
        return idRecurso;
    }

    // Devuelve la URL del recurso web
    public String getUrlWeb() {
        return urlWeb;
    }

    // Devuelve el tipo de recurso (VIDEO, AUDIO o WEB)
    public TipoRecurso getTipo() {
        return tipo;
    }

    // Devuelve true si se están viendo los detalles en la interfaz, y false en caso contrario
    public boolean isExpandido() {
        return expandido;
    }

    // Establece el estado de los detalles del recurso en la interfaz del usuario
    public void setExpandido(boolean expandido) {
        this.expandido = expandido;
    }

    // Devuelve el identificador del icono representativo del recurso
    public int getIdIcono() {
        return idIcono;
    }


    // Implementación de Parcelable

    /**
     * Constructor usado para reconstruir un objeto Recurso a partir de un Parcel
     * in.readString() → Recupera cadenas (titulo, descripcion, urlWeb).
     * in.readInt() → Recupera valores enteros (idRecurso, idIcono).
     * in.readInt() con TipoRecurso.values()[in.readInt()] → Se guarda previamente un enum como su ordinal (posición en el array de valores de TipoRecurso). TipoRecurso.values()[in.readInt()] recupera el valor correcto.
     * in.readByte() != 0 → expandido se guardó como byte (1 para true, 0 para false). Se recupera con != 0, que convierte 1 en true y 0 en false.
     */
    protected Recurso(Parcel in) {
        titulo = in.readString();
        descripcion = in.readString();
        idRecurso = in.readInt();
        urlWeb = in.readString();
        tipo = TipoRecurso.valueOf(in.readString());  // Recuperar nombre del enum
        expandido = in.readByte () != 0;  // Convertir byte a boolean
        idIcono = in.readInt();
    }

    /**
     * Escribe los datos del objeto en un Parcel para su serialización
     *dest.writeString() → Guarda String (titulo, descripcion, urlWeb).
     * dest.writeInt() → Guarda enteros (idRecurso, idIcono).
     * dest.writeInt(tipo.ordinal()) → Guarda el enum como su posición en el array values().
     * dest.writeByte((byte) (expandido ? 1 : 0)) → Guarda expandido como byte (1 o 0).
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(titulo);
        dest.writeString(descripcion);
        dest.writeInt(idRecurso);
        dest.writeString(urlWeb);
        dest.writeString(tipo.name());  // Guardar nombre del enum
        dest.writeByte((byte) (expandido ? 1 : 0));  // Convertir boolean a byte
        dest.writeInt(idIcono);
    }

    /**
     * Indica si el objeto tiene algún tipo especial de contenido
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * Objeto CREATOR requerido para deserializar un objeto Parcelable.
     * Es un objeto necesario para reconstruir un Recurso desde un Parcel.
     * createFromParcel(Parcel in) → Llama al constructor privado Recurso(Parcel in) para leer datos.
     * newArray(int size) → Crea un array de objetos Recurso del tamaño indicado.
     */
    public static final Creator<Recurso> CREATOR = new Creator<Recurso>() {
        @Override
        public Recurso createFromParcel(Parcel in) {
            return new Recurso(in);
        }

        @Override
        public Recurso[] newArray(int size) {
            return new Recurso[size];
        }
    };
}