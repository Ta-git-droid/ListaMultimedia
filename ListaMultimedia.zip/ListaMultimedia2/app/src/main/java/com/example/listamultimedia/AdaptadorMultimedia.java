package com.example.listamultimedia;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdaptadorMultimedia extends RecyclerView.Adapter<AdaptadorMultimedia.ElementoViewHolder> {

    private List<Recurso> listaElementos;
    private OnElementoSeleccionadoListener listener;

    // Constructor para inicializar el adaptador con la lista de recursos y el listener
    public AdaptadorMultimedia(List<Recurso> listaElementos, OnElementoSeleccionadoListener listener) {
        this.listaElementos = listaElementos;
        this.listener = listener;
        Log.d("AdaptadorMultimedia", "Adaptador creado con " + listaElementos.size() + " elementos.");
    }

    @Override
    public ElementoViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflamos el layout de un item en la lista
        Log.d("AdaptadorMultimedia", "Creando ViewHolder.");
        View vista = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_elemento, parent, false);
        return new ElementoViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(ElementoViewHolder holder, int position) {
        // Obtenemos el recurso correspondiente de la lista
        Recurso elemento = listaElementos.get(position);
        Log.d("AdaptadorMultimedia", "Vinculando ViewHolder para el elemento en la posición: " + position);

        // Establecemos el icono, título y descripción del recurso
        holder.imagenIcono.setImageResource(elemento.getIdIcono());
        holder.tituloTextView.setText(elemento.getTitulo());
        holder.descripcionTextView.setText(elemento.getDescripcion());

        // Log para verificar los detalles de cada elemento
        Log.d("AdaptadorMultimedia", "Elemento en posición " + position + ": Titulo = " + elemento.getTitulo());

        // Se maneja el estado expandido del recurso cuando se hace clic en el ítem
        holder.itemView.setOnClickListener(v -> {
            Log.d("AdaptadorMultimedia", "Item en posición " + position + " fue clickeado.");
            elemento.setExpandido(!elemento.isExpandido()); // Cambia el estado expandido
            notifyItemChanged(position); // Notifica que el ítem ha cambiado

            // Log para mostrar el nuevo estado expandido
            Log.d("AdaptadorMultimedia", "Estado expandido cambiado para el elemento en la posición " + position + ": " + elemento.isExpandido());
        });

        // Se muestra u oculta el layout de detalles según el estado expandido
        holder.layoutDetalle.setVisibility(elemento.isExpandido() ? View.VISIBLE : View.GONE);

        // Log para verificar si el layout de detalle está visible o no
        Log.d("AdaptadorMultimedia", "Layout detalle en la posición " + position + " es visible: " + (elemento.isExpandido() ? "Sí" : "No"));

        // Se gestiona el clic en el botón "Ver detalle"
        holder.botonVerDetalle.setOnClickListener(v -> {
            Log.d("AdaptadorMultimedia", "Botón 'Ver detalle' clickeado para el elemento en la posición " + position);
            listener.onElementoSeleccionado(elemento); // Llama al listener para procesar el clic
        });
    }

    @Override
    public int getItemCount() {
        // Retorna el número total de elementos en la lista
        int itemCount = listaElementos.size();
        Log.d("AdaptadorMultimedia", "Número total de elementos en la lista: " + itemCount);
        return itemCount;
    }

    public static class ElementoViewHolder extends RecyclerView.ViewHolder {
        ImageView imagenIcono;
        TextView tituloTextView;
        TextView descripcionTextView;
        LinearLayout layoutDetalle;
        Button botonVerDetalle;

        // Constructor del ViewHolder para inicializar los elementos de la vista
        public ElementoViewHolder(View itemView) {
            super(itemView);
            imagenIcono = itemView.findViewById(R.id.imagen_icono);
            tituloTextView = itemView.findViewById(R.id.titulo_texto);
            descripcionTextView = itemView.findViewById(R.id.descripcion_texto);
            layoutDetalle = itemView.findViewById(R.id.layout_detalle);
            botonVerDetalle = itemView.findViewById(R.id.boton_ver_detalle);
            Log.d("AdaptadorMultimedia", "ElementoViewHolder creado.");
        }
    }

    // Interfaz que maneja el evento de selección de un elemento
    public interface OnElementoSeleccionadoListener {
        void onElementoSeleccionado(Recurso elemento);
    }
}